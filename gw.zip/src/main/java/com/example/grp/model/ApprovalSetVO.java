package com.example.grp.model;

public class ApprovalSetVO {

	private int app_num;
	private int app_A_auth;
	private int app_B_auth;
	private String app_before_sign;
	private String app_other_sign;
	private String app_after_sign;
	private String app_return;
	private String app_view;
	private String app_cencle;
	
	public int getApp_num() {
		return app_num;
	}
	public void setApp_num(int app_num) {
		this.app_num = app_num;
	}
	public int getApp_A_auth() {
		return app_A_auth;
	}
	public void setApp_A_auth(int app_A_auth) {
		this.app_A_auth = app_A_auth;
	}
	public int getApp_B_auth() {
		return app_B_auth;
	}
	public void setApp_B_auth(int app_B_auth) {
		this.app_B_auth = app_B_auth;
	}
	public String getApp_before_sign() {
		return app_before_sign;
	}
	public void setApp_before_sign(String app_before_sign) {
		this.app_before_sign = app_before_sign;
	}
	public String getApp_other_sign() {
		return app_other_sign;
	}
	public void setApp_other_sign(String app_other_sign) {
		this.app_other_sign = app_other_sign;
	}
	public String getApp_after_sign() {
		return app_after_sign;
	}
	public void setApp_after_sign(String app_after_sign) {
		this.app_after_sign = app_after_sign;
	}
	public String getApp_return() {
		return app_return;
	}
	public void setApp_return(String app_return) {
		this.app_return = app_return;
	}
	public String getApp_view() {
		return app_view;
	}
	public void setApp_view(String app_view) {
		this.app_view = app_view;
	}
	public String getApp_cencle() {
		return app_cencle;
	}
	public void setApp_cencle(String app_cencle) {
		this.app_cencle = app_cencle;
	}
	
	
}
