package com.example.grp.model;

public class BuseoVO {
	private String buseo_id;
	private String buseo_name;
	
	public String getBuseo_id() {
		return buseo_id;
	}
	public void setBuseo_id(String buseo_id) {
		this.buseo_id = buseo_id;
	}
	public String getBuseo_name() {
		return buseo_name;
	}
	public void setBuseo_name(String buseo_name) {
		this.buseo_name = buseo_name;
	}
	
}
