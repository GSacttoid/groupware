package com.example.grp.model;

public class ComVO {
	
	private String com_name;
	private String com_code;
	private String com_ceo;
	private String com_file;
	private String com_logo_paper;
	private String com_logo;
	private String com_tel;
	private String com_fax;
	private String com_address;
	private String com_address_num;

	private String logo_name;
	private String logo_sub_name;
	private String com_start;
	
	public String getCom_address_num() {
		return com_address_num;
	}
	public void setCom_address_num(String com_address_num) {
		this.com_address_num = com_address_num;
	}
	public String getCom_start() {
		return com_start;
	}
	public void setCom_start(String com_start) {
		this.com_start = com_start;
	}
	public String getCom_name() {
		return com_name;
	}
	public void setCom_name(String com_name) {
		this.com_name = com_name;
	}
	public String getCom_code() {
		return com_code;
	}
	public void setCom_code(String com_code) {
		this.com_code = com_code;
	}
	public String getCom_ceo() {
		return com_ceo;
	}
	public void setCom_ceo(String com_ceo) {
		this.com_ceo = com_ceo;
	}
	public String getCom_file() {
		return com_file;
	}
	public void setCom_file(String com_file) {
		this.com_file = com_file;
	}
	public String getCom_logo_paper() {
		return com_logo_paper;
	}
	public void setCom_logo_paper(String com_logo_paper) {
		this.com_logo_paper = com_logo_paper;
	}
	public String getCom_logo() {
		return com_logo;
	}
	public void setCom_logo(String com_logo) {
		this.com_logo = com_logo;
	}
	public String getCom_tel() {
		return com_tel;
	}
	public void setCom_tel(String com_tel) {
		this.com_tel = com_tel;
	}
	public String getCom_fax() {
		return com_fax;
	}
	public void setCom_fax(String com_fax) {
		this.com_fax = com_fax;
	}
	public String getCom_address() {
		return com_address;
	}
	public void setCom_address(String com_address) {
		this.com_address = com_address;
	}
	public String getLogo_name() {
		return logo_name;
	}
	public void setLogo_name(String logo_name) {
		this.logo_name = logo_name;
	}
	public String getLogo_sub_name() {
		return logo_sub_name;
	}
	public void setLogo_sub_name(String logo_sub_name) {
		this.logo_sub_name = logo_sub_name;
	}

}
