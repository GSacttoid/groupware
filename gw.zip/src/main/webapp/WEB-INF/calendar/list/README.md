
# FullCalendar List View Plugin

View your events as a bulleted list

[View the docs &raquo;](https://fullcalendar.io/docs/list-view)

This package was created from the [FullCalendar monorepo &raquo;](https://github.com/fullcalendar/fullcalendar)
